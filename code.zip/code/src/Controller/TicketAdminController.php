<?php

namespace App\Controller;

use Cake\Core\Configure;

class TicketAdminController extends AdminController {
	public function index() {

	}
}