
var websiteIsFaded = false;

$(document).ready(function() {
	$(".menu-responsive").click(function() {
		$(".responsive-menu-body").slideToggle(200);
	});
});
