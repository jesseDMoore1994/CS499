
$(document).ready(function() {
	$(".admin-helplink").click(function() {
		$(".help-dropdown").slideToggle();
	});
});
